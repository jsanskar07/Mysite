'use client'
import React, { useState, useEffect } from 'react'
import axios from 'axios'
import Link from 'next/link'
import '../globals.css'


export default function page() {
    const url = `http://localhost:8080/api/employee/All`;
    const [data, setData] = useState([]);

    const fetchInfo = () => {
        return fetch(url)
            .then((res) => res.json())
            .then((d) => setData(d))
    }

    useEffect(() => {
        fetchInfo();
    }, []);
    return (
        <>
            <div className="App">       
            <input type='text'/>         
                <center>
                    {data.map((emp) => {
                        return (
                            <div className='px-24 py-2'>
                            <div key={emp.empID}className="flex flex-col border-gray-300 border bg-white divide-y rounded-lg flex-none w-full">
                                <div className="flex flex-col space-y-2 divide-y">

                                    <div className="flex justify-between space-x-6 items-center p-6">
                                        <div className="flex items-center space-x-4">
                                            <img src="https://flowbite.com/docs/images/people/profile-picture-1.jpg" className="rounded-full h-14 w-14" alt="" />
                                            <div className="flex flex-col space-y-2">
                                                <span>{emp.firstName + " " + emp.lastName}</span>
                                                <span>{emp.email}</span>
                                            </div>

                                        </div>
                                        <div>
                                            <Link href="#">
                                                <button className="border rounded-md px-4 py-2">
                                                    View
                                                </button>
                                            </Link>
                                        </div>
                                    </div>
                                </div>                                
                            </div>
                            </div>
                        );
                    })}
                </center>
            </div>
            
        </>
    )
}
