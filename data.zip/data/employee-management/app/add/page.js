'use client'
import React, { useState } from 'react'
import axios from 'axios'
import '../globals.css'
const page = () => {
    const [fname, setFname] = useState("");
    const [lname, setLname] = useState("");
    const [email, setEmail] = useState("");
    const [address, setAddress] = useState("");
    const url = "http://localhost:8080/api/employee/All"
    var body =  {
        "firstName": fname,
        "lastName": lname,
        "email": email,
        "address": address
    }
    const options = {
        method: "POST",
        headers: { "content-type": "application/json" },
        data: body,
        url : url
    }
    async function handleClick() {
        axios(options)
        .then(res => {
          console.log("data is inserted");
        })
        .catch(er => {
          console.log("no data sorry ", er);
        });          
    }
    return (<>
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col my-6 mx-12">
            <div className="-mx-3 md:flex mb-6">
                <div className="md:w-1/2 px-3 mb-6 md:mb-0">
                    <label className="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2" htmlFor="grid-first-name">
                        First Name
                    </label>
                    <input className="appearance-none block w-full bg-grey-lighter text-grey-darker border border-red rounded py-3 px-4 mb-3" id="grid-first-name" type="text" placeholder="Enter First Name" value={fname} onChange={e => setFname(e.target.value)} />
                    <p className="text-red text-xs italic">Please fill out this field.</p>
                </div>
                <div className="md:w-1/2 px-3">
                    <label className="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2" htmlFor="grid-last-name">
                        Last Name
                    </label>
                    <input className="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4" id="grid-last-name" type="text" placeholder="Enter Last Name" value={lname} onChange={e => setLname(e.target.value)} />
                </div>
            </div>
            <div className="-mx-3 md:flex mb-6">
                <div className="md:w-full px-3">
                    <label className="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2" htmlFor="email">
                        email
                    </label>
                    <input className="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3" id="email" type="email" placeholder="abc@gmail.com" value={email} onChange={e => setEmail(e.target.value)}/>
                    <p className="text-grey-dark text-xs italic">Please enter a valid email</p>
                </div>
            </div>
            <div className="-mx-3 md:flex mb-6">
                <div className="md:w-full px-3">
                    <label className="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2" htmlFor="text">
                        Address
                    </label>
                    <input className="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3" id="address" type="text" placeholder="Enter your address" value={address} onChange={e => setAddress(e.target.value)}/>
                    <p className="text-grey-dark text-xs italic">Please enter your address</p>
                </div>
            </div>
            <button className="w-full py-3 font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg border-indigo-500 hover:shadow inline-flex space-x-2 items-center justify-center" onClick={handleClick}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                      </svg>
                      <span>Submit</span>
            </button>
            
        </div>
    </>

    )
}

export default page;
