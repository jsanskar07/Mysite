import Navbar from "@/components/Navbar";
//import SearchPage from "@/components/SearchPage";
import './globals.css'
import HeroSection from "@/components/HeroSection";
export default function Page() {
  return (
    <>      
      <HeroSection/>           
    </>
  );
}