import Link from 'next/link';
import React from 'react'

const Card = () => {
    
  return (
    <div>     

    <div className="flex flex-col border-gray-300 border bg-white divide-y rounded-lg flex-none w-full">
        <div className="flex flex-col space-y-2 divide-y">
            
            <div className="flex justify-between space-x-6 items-center p-6">
                <div className="flex items-center space-x-4">
                    <img src="https://flowbite.com/docs/images/people/profile-picture-1.jpg" className="rounded-full h-14 w-14" alt=""/>
                    <div className="flex flex-col space-y-2">
                        <span>Leonard Krashner</span>
                        <span>@Leonardkrashner</span>
                    </div>
                    
                </div>
                <div>
                    <Link href="/details">
                    <button className="border rounded-md px-4 py-2">
                        View
                    </button>
                    </Link>
                </div>
            </div>    
            
            
            
        </div>
        <div className="p-4">
            <button className="w-full border p-2 rounded-md hover:opacity-60 transition">View all</button>
        </div>
    </div>
</div>
    
  )
}

export default Card;

