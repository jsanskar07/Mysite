import React from 'react'

const Details = () => {
  return (
    <div>
      <h1>Hello from Details Page</h1> 
    </div>
  )
}

export default Details;
