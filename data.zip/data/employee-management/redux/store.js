'use client';
import { configureStore } from "@reduxjs/toolkit";
import apiReducer from "@/redux/slice/api";



export const store = configureStore({
    reducer: {
        api : apiReducer,        
    },
});