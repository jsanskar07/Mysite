// import { createSlice, createAsyncThunk  } from "@reduxjs/toolkit";

// // export const fetchapi = createAsyncThunk("fetchapi", async() => {
// //     const response = await fetch("http://localhost:8080/api/employee");
// //     return response.json();
// // });

// const apiSlice = createSlice({
//     name : "apiSlice",
//     initialState : {
//         isLoading : false,
//         data : null,
//         isError : false
//     },
//     extraReducers : (builder) => {
//         builder.addCase(fetchapi.pending, (state, action) => {
//             state.isLoading = true;                
//         })
//         builder.addCase(fetchapi.fulfilled, (state, action) => {
//             state.isLoading = false,
//             state.data = action.payload;
//         });
//         builder.addCase(fetchapi.rejected, (state, action) => {
//             console.log("Error" , action.payload);
//             state.isError = true;
//         })
//     }
// });

// export default apiSlice.reducer;